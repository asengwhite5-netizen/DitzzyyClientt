package com.ditzzyy.client.mixin;

import com.ditzzyy.client.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {
    // Hitbox Expander: perbesar margin targeting (crosshair) tanpa ngubah hitbox asli
    @Inject(method = "getTargetingMargin", at = @At("HEAD"), cancellable = true)
    private void ditzzyy$margin(CallbackInfoReturnable<Float> cir) {
        Object self = this;
        if (Modules.HITBOX.enabled && self instanceof LivingEntity
                && self != MinecraftClient.getInstance().player) {
            cir.setReturnValue(Modules.HITBOX.size);
        }
    }
}
