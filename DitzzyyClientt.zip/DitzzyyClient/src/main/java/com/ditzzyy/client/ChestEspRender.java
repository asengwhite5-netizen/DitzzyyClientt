package com.ditzzyy.client;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Bagian ini paling sensitif sama perubahan render API di 1.21.x.
 * Kalau compile error, kirim error-nya, gue benerin.
 */
public class ChestEspRender {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            if (!Modules.CHEST_ESP.enabled) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
            VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
            for (BlockEntity be : Modules.CHEST_ESP.scan()) {
                Box b = new Box(be.getPos()).offset(-cam.x, -cam.y, -cam.z);
                VertexRendering.drawBox(ctx.matrices(), vc, b, 1f, 0.75f, 0f, 1f);
            }
        });
    }
}
