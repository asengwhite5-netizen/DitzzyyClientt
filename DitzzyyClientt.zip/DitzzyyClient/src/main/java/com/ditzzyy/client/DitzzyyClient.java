package com.ditzzyy.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class DitzzyyClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        KeyBinding guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ditzzyyclient.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (guiKey.wasPressed()) mc.setScreen(new ClickGui());
            if (mc.player == null) return;
            for (Module m : Modules.ALL) if (m.enabled) m.onTick();
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient()) Modules.SLAM.onAttack(entity);
            return ActionResult.PASS;
        });

        ChestEspRender.register();
    }
}
