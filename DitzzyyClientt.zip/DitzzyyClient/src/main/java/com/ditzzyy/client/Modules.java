package com.ditzzyy.client;

import net.minecraft.block.entity.*;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.List;

public class Modules {

    public static final AimAssist AIM = new AimAssist();
    public static final Hitbox HITBOX = new Hitbox();
    public static final SlamStun SLAM = new SlamStun();
    public static final ChestEsp CHEST_ESP = new ChestEsp();
    public static final Esp ESP = new Esp();
    public static final Brightness BRIGHT = new Brightness();
    public static final Fly FLY = new Fly();
    public static final EntityControl ENTITY = new EntityControl();

    public static final List<Module> ALL = List.of(AIM, HITBOX, SLAM, CHEST_ESP, ESP, BRIGHT, FLY, ENTITY);

    // ---------- Aim Assist ----------
    public static class AimAssist extends Module {
        public float range = 4.5f, fov = 60f, smooth = 0.25f;
        AimAssist() { super("Aim Assist"); }
        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.world == null || mc.currentScreen != null) return;
            double best = Double.MAX_VALUE; float bdy = 0, bdp = 0; boolean found = false;
            for (PlayerEntity t : mc.world.getPlayers()) {
                if (t == p || !t.isAlive() || p.distanceTo(t) > range) continue;
                Vec3d to = t.getBoundingBox().getCenter().subtract(p.getEyePos());
                float ty = (float) (MathHelper.atan2(to.z, to.x) * 180 / Math.PI) - 90f;
                float tp = (float) -(MathHelper.atan2(to.y, Math.hypot(to.x, to.z)) * 180 / Math.PI);
                float dy = MathHelper.wrapDegrees(ty - p.getYaw());
                float dp = tp - p.getPitch();
                double ang = Math.hypot(dy, dp);
                if (ang > fov || ang >= best) continue;
                best = ang; bdy = dy; bdp = dp; found = true;
            }
            if (!found) return;
            p.setYaw(p.getYaw() + bdy * smooth);
            p.setPitch(MathHelper.clamp(p.getPitch() + bdp * smooth, -90f, 90f));
        }
    }

    // ---------- Hitbox Expander (logic di EntityMixin) ----------
    public static class Hitbox extends Module {
        public float size = 0.4f;
        Hitbox() { super("Hitbox Expander"); }
    }

    // ---------- Slam Stun: axe dulu buat nurunin shield, balik ke mace buat slam ----------
    public static class SlamStun extends Module {
        private boolean busy;
        SlamStun() { super("Slam Stun"); }

        private int slotOf(boolean mace) {
            for (int i = 0; i < 9; i++) {
                var s = mc.player.getInventory().getStack(i);
                if (mace ? s.isOf(Items.MACE) : s.getItem() instanceof AxeItem) return i;
            }
            return -1;
        }

        /** dipanggil dari AttackEntityCallback (client side) */
        public void onAttack(Entity target) {
            if (!enabled || busy || mc.player == null || mc.interactionManager == null) return;
            if (!(target instanceof PlayerEntity t) || !t.isBlocking()) return;
            if (!mc.player.getMainHandStack().isOf(Items.MACE) || mc.player.fallDistance < 1.5f) return;
            int axe = slotOf(false), mace = mc.player.getInventory().getSelectedSlot();
            if (axe < 0) return;
            busy = true;
            try {
                mc.player.getInventory().setSelectedSlot(axe);
                mc.interactionManager.attackEntity(mc.player, target);
                mc.player.swingHand(Hand.MAIN_HAND);
                mc.player.getInventory().setSelectedSlot(mace);
            } finally { busy = false; }
        }
    }

    // ---------- Chest ESP (data di sini, render di ChestEspRender) ----------
    public static class ChestEsp extends Module {
        public int chunkRadius = 6;
        ChestEsp() { super("Chest ESP"); }

        public java.util.List<BlockEntity> scan() {
            var out = new java.util.ArrayList<BlockEntity>();
            if (mc.world == null || mc.player == null) return out;
            int cx = mc.player.getBlockPos().getX() >> 4, cz = mc.player.getBlockPos().getZ() >> 4;
            for (int x = -chunkRadius; x <= chunkRadius; x++)
                for (int z = -chunkRadius; z <= chunkRadius; z++) {
                    WorldChunk c = mc.world.getChunkManager().getWorldChunk(cx + x, cz + z);
                    if (c == null) continue;
                    for (BlockEntity be : c.getBlockEntities().values())
                        if (be instanceof ChestBlockEntity || be instanceof EnderChestBlockEntity
                                || be instanceof ShulkerBoxBlockEntity || be instanceof BarrelBlockEntity)
                            out.add(be);
                }
            return out;
        }
    }

    // ---------- ESP (glow outline tembus tembok) ----------
    public static class Esp extends Module {
        Esp() { super("ESP"); }
        @Override public void onTick() {
            if (mc.world == null) return;
            for (PlayerEntity p : mc.world.getPlayers()) if (p != mc.player) p.setGlowing(true);
        }
        @Override public void onDisable() {
            if (mc.world == null) return;
            for (PlayerEntity p : mc.world.getPlayers()) p.setGlowing(false);
        }
    }

    // ---------- Brightness (night vision client side) ----------
    public static class Brightness extends Module {
        Brightness() { super("Brightness"); }
        @Override public void onTick() {
            if (mc.player != null)
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 420, 0, false, false, false));
        }
        @Override public void onDisable() {
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    // ---------- Fly ----------
    public static class Fly extends Module {
        public float speed = 0.1f;
        Fly() { super("Fly"); }
        @Override public void onTick() {
            if (mc.player == null) return;
            var a = mc.player.getAbilities();
            a.allowFlying = true; a.flying = true; a.setFlySpeed(speed);
        }
        @Override public void onDisable() {
            if (mc.player == null) return;
            var a = mc.player.getAbilities();
            a.setFlySpeed(0.05f);
            if (!mc.player.isCreative() && !mc.player.isSpectator()) { a.allowFlying = false; a.flying = false; }
        }
    }

    // ---------- Entity Control: kendalikan kendaraan/mount tanpa saddle ----------
    public static class EntityControl extends Module {
        public double speed = 0.6;
        EntityControl() { super("Entity Control"); }
        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || p.getVehicle() == null) return;
            Entity v = p.getVehicle();
            v.setYaw(p.getYaw());
            Vec3d vel = v.getVelocity();
            double x = 0, z = 0, y = vel.y;
            if (mc.options.forwardKey.isPressed()) {
                Vec3d d = Vec3d.fromPolar(0, p.getYaw()).multiply(speed);
                x = d.x; z = d.z;
            }
            if (mc.options.jumpKey.isPressed()) y = 0.3;
            v.setVelocity(x, y, z);
        }
    }
}
